/**
 * 冶金矿产行业线知识库 - 数据配置
 * 新增文件只需在对应数组中添加一条记录即可
 * 最后更新: 2026-04-02
 */

const KB_DATA = {
  meta: {
    title: "冶金矿产行业线知识库",
    subtitle: "会议资料 · 会议纪要 · 每日资讯 · 重点通知",
    lastUpdated: "2026-04-02",
    team: "审计板块·冶金矿产行业线"
  },

  // ===== 重点通知（置顶公告栏）=====
  notices: [
    // 示例格式（取消注释并填写即可）：
    // {
    //   id: "notice-001",
    //   title: "关于XXX的重要通知",
    //   date: "2026-04-02",
    //   content: "通知正文内容...",
    //   tag: "重要",
    //   tagColor: "#e53935"
    // }
  ],

  // ===== 合伙人经理会议材料 =====
  meetings: [
    {
      id: "meeting-20251107",
      title: "【冶金矿产行业线】第一次合伙人经理会议材料",
      date: "2025-11-07",
      version: "V20251107",
      type: "pdf",
      file: "files/meetings/【冶金矿产行业线】第一次合伙人经理会议材料V20251107.pdf",
      tags: ["合伙人会议", "行业线"],
      summary: "冶金矿产行业线第一次合伙人经理会议材料正式版，包含行业分析、客户动态及工作部署"
    },
    {
      id: "meeting-20250916",
      title: "【冶金矿产行业线】第一次合伙人经理会议材料",
      date: "2025-09-16",
      version: "V20250916",
      type: "pdf",
      file: "files/meetings/【冶金矿产行业线】第一次合伙人经理会议材料V20250916.pdf",
      tags: ["合伙人会议", "行业线"],
      summary: "冶金矿产行业线第一次合伙人经理会议材料初稿版本"
    }
  ],

  // ===== 经营例会纪要 =====
  minutes: [
    {
      id: "minutes-20260402",
      title: "2026年4月2日 审计板块行业线经营例会纪要",
      date: "2026-04-02",
      type: "image",
      file: "files/minutes/2026年4月2日 审计板块行业线经营例会纪要.png",
      tags: ["经营例会", "2026年"],
      summary: "2026年4月2日审计板块冶金矿产行业线经营例会纪要"
    },
    {
      id: "minutes-20260202",
      title: "2026年2月2日 审计板块行业线经营例会纪要",
      date: "2026-02-02",
      type: "image",
      file: "files/minutes/2026年2月2日 审计板块行业线经营例会纪要.png",
      tags: ["经营例会", "2026年"],
      summary: "2026年2月2日审计板块冶金矿产行业线经营例会纪要"
    }
  ],

  // ===== 每日资讯 =====
  // 新增日报时在此数组最前面添加一条记录
  dailyNews: [
    {
      id: "daily-20260402",
      title: "冶金矿产行业线每日资讯",
      date: "2026-04-02",
      displayDate: "2026年4月2日",
      type: "html",
      file: "files/daily/冶金矿产_每日资讯_20260402_商务版.html",
      tags: ["每日资讯"],
      highlights: ["洛阳钼业+6.36%发布H股年报", "盛屯矿业一季度净利预增226%-295%", "国际金价$4495/盎司+2.68%"]
    },
    {
      id: "daily-20260331",
      title: "冶金矿产行业线每日资讯",
      date: "2026-03-31",
      displayDate: "2026年3月31日",
      type: "html",
      file: "files/daily/冶金矿产_每日资讯_20260331_商务版.html",
      tags: ["每日资讯"],
      highlights: ["首钢股份停牌（3/27起）", "盛和资源稀土价格跟踪", "钢铁板块整体承压"]
    },
    {
      id: "daily-20260330",
      title: "冶金矿产行业线每日资讯",
      date: "2026-03-30",
      displayDate: "2026年3月30日",
      type: "html",
      file: "files/daily/冶金矿产_每日资讯_20260330_商务版.html",
      tags: ["每日资讯"],
      highlights: ["山东黄金2025年报净利47.39亿+60.57%", "有色金属价格分化", "稀土政策关注"]
    },
    {
      id: "daily-20260328",
      title: "冶金矿产行业线每日资讯",
      date: "2026-03-28",
      displayDate: "2026年3月28日",
      type: "html",
      file: "files/daily/冶金矿产_每日资讯_20260328_商务版.html",
      tags: ["每日资讯"],
      highlights: ["首钢股份3月27日停牌", "钢铁行业承压", "洛阳钼业海外扩张"]
    },
    {
      id: "daily-20260327",
      title: "冶金矿产行业线每日资讯",
      date: "2026-03-27",
      displayDate: "2026年3月27日",
      type: "html",
      file: "files/daily/冶金矿产_每日资讯_20260327_商务版.html",
      tags: ["每日资讯"],
      highlights: ["黄金价格继续高位", "有色金属行情", "行业政策动向"]
    },
    {
      id: "daily-20260326",
      title: "冶金矿产行业线每日资讯",
      date: "2026-03-26",
      displayDate: "2026年3月26日",
      type: "html",
      file: "files/daily/冶金矿产_每日资讯_20260326_商务版.html",
      tags: ["每日资讯"],
      highlights: ["云南铜业纳入客户名单", "洛阳钼业完成巴西金矿收购", "铜价冲高"]
    },
    {
      id: "daily-20260325",
      title: "冶金矿产行业线每日资讯",
      date: "2026-03-25",
      displayDate: "2026年3月25日",
      type: "html",
      file: "files/daily/冶金矿产_每日资讯_20260325_商务版.html",
      tags: ["每日资讯"],
      highlights: ["有色金属整体行情", "稀土价格跟踪", "客户动态"]
    }
  ]
};

// 全部文档（用于搜索）
KB_DATA.allDocs = [
  ...KB_DATA.meetings.map(d => ({...d, category: "meeting", categoryName: "合伙人经理会议"})),
  ...KB_DATA.minutes.map(d => ({...d, category: "minutes", categoryName: "经营例会纪要"})),
  ...KB_DATA.dailyNews.map(d => ({...d, category: "daily", categoryName: "每日资讯"}))
].sort((a, b) => b.date.localeCompare(a.date));

KB_DATA.stats = {
  total: KB_DATA.allDocs.length,
  meetings: KB_DATA.meetings.length,
  minutes: KB_DATA.minutes.length,
  dailyNews: KB_DATA.dailyNews.length,
  notices: KB_DATA.notices.length
};
